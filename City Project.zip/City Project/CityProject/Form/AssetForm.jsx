import { useState } from "react";
import "./AssetForm.css"; // Import the CSS file

export default function AssetForm() {
    const [formData, setFormData] = useState({
        firstName: "",
        lastName: "",
        address: "",
        state: "",
        country: "",
        zipCode: "",
        assetName: "",
        projectName: "",
        assetDetails: "",
    });

    const [errors, setErrors] = useState({});

    const handleChange = (e) => {
        setFormData({ ...formData, [e.target.name]: e.target.value });
    };

    const validateForm = () => {
        let newErrors = {};
        Object.keys(formData).forEach((field) => {
            if (!formData[field]) {
                newErrors[field] = "This field is required";
            }
        });
        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    const handleSubmit = async (e) => {
        e.preventDefault();

        if (!validateForm()) return;

        try {
            const response = await fetch("http://localhost:3000/addDetails", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(formData),
            });

            if (!response.ok) {
                throw new Error("Failed to submit form");
            }

            alert("Form submitted successfully!");
            setFormData({
                firstName: "",
                lastName: "",
                address: "",
                state: "",
                country: "",
                zipCode: "",
                assetName: "",
                projectName: "",
                assetDetails: "",
            });
            setErrors({});
        } catch (error) {
            alert("Error submitting form: " + error.message);
        }
    };

    return (
        <div className="form-container">
            <div className="form-box">
                <h2 className="form-title">Asset Submission Form</h2>
                <form onSubmit={handleSubmit}>
                    {Object.keys(formData).map((field) => (
                        <div key={field} className="form-group">
                            <label className="form-label">
                                {field.replace(/([A-Z])/g, " $1")}
                            </label>
                            <input
                                type="text"
                                name={field}
                                value={formData[field]}
                                onChange={handleChange}
                                className="form-input"
                                placeholder={`Enter ${field.replace(/([A-Z])/g, " $1")}`}
                            />
                            {errors[field] && <p className="error-text">{errors[field]}</p>}
                        </div>
                    ))}
                    <button type="submit" className="submit-button">
                        Submit
                    </button>
                </form>
            </div>
        </div>
    );
}
