
import './App.css'
import AssetForm from '../Form/AssetForm'

function App() {

  return (
    <AssetForm />
  )
}

export default App
