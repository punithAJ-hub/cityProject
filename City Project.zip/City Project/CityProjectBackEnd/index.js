const express = require('express');
const mysql = require('mysql2'); // Change to 'pg' for PostgreSQL
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 3000;

// Middleware
app.use(cors()); // Enable CORS
app.use(bodyParser.json()); // Parse JSON request body

// ✅ Change this to your actual MySQL/PostgreSQL credentials
const db = mysql.createConnection({
  host: 'localhost',
  user: 'root', // Change this to your DB user
  password: 'password', // Change this to your DB password
  database: 'assets_db', // Change this to your actual DB name
});

// Connect to the database
db.connect((err) => {
  if (err) {
    console.error('Database connection failed: ' + err.stack);
    return;
  }
  console.log('Connected to the database.');
});

// Route to handle form submission
app.post('/addDetails', (req, res) => {
  const {
    firstName,
    lastName,
    address,
    state,
    country,
    zipCode,
    assetName,
    projectName,
    assetDetails,
  } = req.body;

  if (!firstName || !lastName || !address || !state || !country || !zipCode || !assetName || !projectName || !assetDetails) {
    return res.status(400).json({ message: 'All fields are required' });
  }

  const sql = `INSERT INTO assets (firstName, lastName, address, state, country, zipCode, assetName, projectName, assetDetails)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;

  db.query(sql, [firstName, lastName, address, state, country, zipCode, assetName, projectName, assetDetails], (err, result) => {
    if (err) {
      console.error('Error inserting data:', err);
      return res.status(500).json({ message: 'Database error' });
    }
    res.status(201).json({ message: 'Data added successfully!', id: result.insertId });
  });
});

// Start the server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
  });